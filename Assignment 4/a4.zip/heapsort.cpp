#include <iostream>

using namespace std;

// This function exchanges the values of var1 and var2.
void Swap(int& var1, int& var2) 
{
   // TODO
}

// This function performs the 'percolate down' operation from node arr[index].
void PercolateDown(int arr[], int index, int size) 
{
   // TODO
}

// This function swaps the minimum-value element with the last element 
// in arr[first..last] and leaves (does not delete) the minimum-value element.
// After DeleteMin, the heap shrinks by 1.
void DeleteMin(int arr[], int& last) 
{
   // TODO
}

// This functions coverts the array arr[] to a heap, i.e., it has the *head-order* 
// property while it is interpreted as a complete binary tree.
void BuildHeap(int arr[], int size)
{
   // TODO
}

// This is the 'heapsort' function that sorts the array arr[] in *descending* order. 
// You may want to use the BuildHeap and DeleteMin functions in this function. 
void Heapsort(int arr[], int size)
{
   // TODO
}

int main()
{
   cout << "Please enter the length (number of elements) of the input array: ";
   int size;
   cin >> size;

   if(size <= 0) {
      cout << "Illegal input array length!" << endl;
      return 0;
   }

   int* arr = new int[size+1];

   cout << "Please enter each element in the array" << endl; 
   cout << "(each element must be an integer within the range of int type)." << endl;
   for(int i = 1; i <= size; i++) {
      cout << "arr[" << i << "] = ";
      cin >> arr[i];
   }

   cout << "The input array arr[] is: "; 
   for(int i = 1; i < size; i++)
      cout << arr[i] << ",";
   cout << arr[size] << endl;

   Heapsort(arr,size); 

   cout << "After heapsort, the sorted array arr[] is: "; 
   for(int i = 1; i < size; i++)
      cout << arr[i] << ",";
   cout << arr[size] << endl;

   delete [] arr;

   return 0;
}